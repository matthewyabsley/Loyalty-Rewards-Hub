# Tap Yard - Restaurant Loyalty App

## OpenLiteSpeed Installation Guide

This package contains the production build of the Tap Yard web application, ready to be deployed on an OpenLiteSpeed web server.

### Prerequisites

- OpenLiteSpeed installed and running
- Root or sudo access to the server
- A domain name pointed to your server (optional but recommended)

---

### Step 1: Upload Files

Copy the contents of the `dist/` folder to your web root directory. The default OpenLiteSpeed web root is:

```
/usr/local/lsws/DEFAULT/html/
```

If you are using a virtual host with a custom document root, use that path instead.

```bash
# Remove default files (optional)
sudo rm -rf /usr/local/lsws/DEFAULT/html/*

# Copy the Tap Yard build files
sudo cp -r dist/* /usr/local/lsws/DEFAULT/html/

# Set ownership
sudo chown -R nobody:nogroup /usr/local/lsws/DEFAULT/html/
```

### Step 2: Configure Rewrite Rules for Single Page Application

Tap Yard is a single page application (SPA) that uses client-side routing. OpenLiteSpeed must be configured to serve `index.html` for all routes that don't match a static file.

#### Option A: Using the WebAdmin Console

1. Open the OpenLiteSpeed WebAdmin panel (default: `https://your-server-ip:7080`)
2. Navigate to **Virtual Hosts** > **Your Virtual Host** > **Context**
3. Click **Add** and select **Static** context type
4. Set the following:
   - **URI**: `/`
   - **Location**: `$DOC_ROOT/`
5. Navigate to **Virtual Hosts** > **Your Virtual Host** > **Rewrite**
6. Set **Enable Rewrite** to **Yes**
7. Add these **Rewrite Rules**:

```
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [L,QSA]
```

8. Click **Save** and then **Graceful Restart** from the top-right menu

#### Option B: Using .htaccess

Create a `.htaccess` file in your document root:

```bash
sudo nano /usr/local/lsws/DEFAULT/html/.htaccess
```

Add the following content:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # If the request is not for an existing file
  RewriteCond %{REQUEST_FILENAME} !-f
  # If the request is not for an existing directory
  RewriteCond %{REQUEST_FILENAME} !-d

  # Send all other requests to index.html
  RewriteRule ^(.*)$ /index.html [L,QSA]
</IfModule>

# Enable gzip compression
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json image/svg+xml
</IfModule>

# Cache static assets
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css "access plus 1 year"
  ExpiresByType application/javascript "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
  ExpiresByType font/woff2 "access plus 1 year"
</IfModule>
```

Note: For `.htaccess` to work, make sure **Allow Override** is enabled in your virtual host configuration. Go to **WebAdmin** > **Virtual Hosts** > **General** > set **Allow Override** to **All**.

### Step 3: Enable Gzip/Brotli Compression (Recommended)

1. In WebAdmin, go to **Server Configuration** > **Tuning**
2. Under **GZIP Compression**, set:
   - **Enable Compression**: Yes
   - **Compressible Types**: `text/html, text/css, application/javascript, application/json, image/svg+xml`

### Step 4: Restart OpenLiteSpeed

```bash
sudo /usr/local/lsws/bin/lswsctrl restart
```

Or use the **Graceful Restart** button in the WebAdmin panel.

### Step 5: Verify

Open your browser and navigate to your server's IP address or domain. You should see the Tap Yard welcome screen.

Try navigating directly to a route like `/home` or `/rewards` and refreshing the page. If the rewrite rules are configured correctly, the app should load without a 404 error.

---

### Directory Structure

```
dist/
  index.html              - Main HTML entry point
  assets/
    index-XXXXXXXX.css    - Compiled CSS styles
    index-XXXXXXXX.js     - Compiled JavaScript bundle
```

### SSL/HTTPS Setup (Recommended)

For production use, set up SSL using Let's Encrypt:

1. Install Certbot:
   ```bash
   sudo apt install certbot
   ```

2. Generate certificate:
   ```bash
   sudo certbot certonly --webroot -w /usr/local/lsws/DEFAULT/html -d yourdomain.com
   ```

3. In WebAdmin, go to **Listeners** > **Add New Listener**:
   - **Port**: 443
   - **Secure**: Yes
   - **SSL Private Key**: `/etc/letsencrypt/live/yourdomain.com/privkey.pem`
   - **SSL Certificate**: `/etc/letsencrypt/live/yourdomain.com/fullchain.pem`

4. Map the listener to your virtual host and restart.

---

### Troubleshooting

| Issue | Solution |
|-------|----------|
| Blank page | Check browser console for errors. Verify all files in `dist/` were copied. |
| 404 on page refresh | Rewrite rules are not configured. Follow Step 2 above. |
| Assets not loading | Check file permissions. Run `sudo chown -R nobody:nogroup /usr/local/lsws/DEFAULT/html/` |
| Fonts not displaying | Ensure Google Fonts CDN is accessible from the server network. |

### Notes

- This is a front-end only build. All data is stored in the browser's localStorage.
- No backend server or database is required for this deployment.
- Currency is displayed in British pounds (GBP).
